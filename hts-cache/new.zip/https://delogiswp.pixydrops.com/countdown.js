<!doctype html>
<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>Page not found &#8211; Delogis</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Delogis &raquo; Feed" href="https://delogiswp.pixydrops.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Delogis &raquo; Comments Feed" href="https://delogiswp.pixydrops.com/comments/feed/" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/delogiswp.pixydrops.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://delogiswp.pixydrops.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.2' media='all' />
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8.4' media='all' />
<link rel='stylesheet' id='layerdrops-toolbar-css-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/layerdrops-toolbar/assets/css/layerdrops-toolbar.css?ver=1704183160' media='all' />
<style id='woocommerce-inline-inline-css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='animate-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/animate/animate.min.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='custom-animate-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/animate/custom-animate.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='bootstrap-select-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/bootstrap-select/css/bootstrap-select.min.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='bxslider-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/bxslider/jquery.bxslider.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='jarallax-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jarallax/jarallax.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='jquery-magnific-popup-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='odometer-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/odometer/odometer.min.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='owl-carousel-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/owl-carousel/owl.carousel.min.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='owl-theme-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/owl-carousel/owl.theme.default.min.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='reey-font-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/reey-font/stylesheet.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='alagambe-font-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/alagambe-font/stylesheet.css?ver=1682955440' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='timepicker-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/timepicker/timePicker.css?ver=1687509198' media='all' />
<link rel='stylesheet' id='jquery-ui-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-ui/jquery-ui.css?ver=1687509198' media='all' />
<link rel='stylesheet' id='delogis-addon-style-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/css/delogis-addon.css?ver=1682955174' media='all' />
<link rel='stylesheet' id='slick-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/slick/slick.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='perfect-scrollbar-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/perfect-scrollbar/css/perfect-scrollbar.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='perfect-scrollbar-wpc-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/perfect-scrollbar/css/custom-theme.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='magnific-popup-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/magnific-popup/magnific-popup.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='woosq-feather-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/feather/feather.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='woosq-frontend-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/css/frontend.css?ver=3.5.4' media='all' />
<link rel='stylesheet' id='woosw-icons-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-wishlist/assets/css/icons.css?ver=4.7.9' media='all' />
<link rel='stylesheet' id='woosw-frontend-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-wishlist/assets/css/frontend.css?ver=4.7.9' media='all' />
<style id='woosw-frontend-inline-css'>
.woosw-popup .woosw-popup-inner .woosw-popup-content .woosw-popup-content-bot .woosw-notice { background-color: #5fbd74; } .woosw-popup .woosw-popup-inner .woosw-popup-content .woosw-popup-content-bot .woosw-popup-content-bot-inner a:hover { color: #5fbd74; border-color: #5fbd74; } 
</style>
<link rel='stylesheet' id='delogis-fonts-css' href='//fonts.googleapis.com/css?family=Lexend%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C600%2C600i%2C700%2C700i%2C800%2C900%7CCastoro%3A400%26subset%3Dlatin%2Clatin-ext' media='all' />
<link rel='stylesheet' id='flaticons-css' href='https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/flaticons/css/flaticon.css?ver=1.1' media='all' />
<link rel='stylesheet' id='delogis-icons-css' href='https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/delogis-icons/style.css?ver=1.1' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/bootstrap/css/bootstrap.min.css?ver=5.0.0' media='all' />
<link rel='stylesheet' id='fontawesome-css' href='https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/fontawesome/css/all.min.css?ver=5.15.1' media='all' />
<link rel='stylesheet' id='delogis-style-css' href='https://delogiswp.pixydrops.com/wp-content/themes/delogis/style.css?ver=1704183160' media='all' />
<style id='delogis-style-inline-css'>
:root {
			--delogis-primary: #f2edea;
			--delogis-primary-rgb: 242, 237, 234;

			--delogis-base: #976147;
			--delogis-base-rgb: 151, 97, 71;

			--delogis-black: #1a1414;
			--delogis-black-rgb: 26, 20, 20;
		}.page-header-bg { background-image: url(https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/page-header-bg.jpg); } .preloader .preloader__image { background-image: url(https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/loader.png); } 
@font-face {
			font-family: "star";
			src: url("https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/fonts/star.eot");
			src: url("https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/fonts/star.eot?#iefix") format("embedded-opentype"),
				url("https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/fonts/star.woff") format("woff"),
				url("https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/fonts/star.ttf") format("truetype"),
				url("https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/fonts/star.svg#star") format("svg");
			font-weight: normal;
			font-style: normal;
		}
</style>
<link rel='stylesheet' id='recent-posts-widget-with-thumbnails-public-style-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/recent-posts-widget-with-thumbnails/public.css?ver=7.1.1' media='all' />
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script><script src="https://delogiswp.pixydrops.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js?ver=1704183160" id="js-cookie-js" data-wp-strategy="defer"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.3.1" id="jquery-blockui-js" data-wp-strategy="defer"></script>
<script id="wc-add-to-cart-js-extra">
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/delogiswp.pixydrops.com\/delogis-cart\/","is_cart":"","cart_redirect_after_add":"no"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=8.3.1" id="wc-add-to-cart-js" defer data-wp-strategy="defer"></script>
<script id="woocommerce-js-extra">
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=8.3.1" id="woocommerce-js" defer data-wp-strategy="defer"></script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/wp-util.min.js?ver=6.4.2" id="wp-util-js"></script>
<link rel="https://api.w.org/" href="https://delogiswp.pixydrops.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://delogiswp.pixydrops.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.2" />
<meta name="generator" content="WooCommerce 8.3.1" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.18.1; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-swap">
<link rel="icon" href="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/favicon-32x32-1.png" sizes="32x32" />
<link rel="icon" href="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/favicon-32x32-1.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/favicon-32x32-1.png" />
<meta name="msapplication-TileImage" content="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/favicon-32x32-1.png" />
</head>

<body class="error404 theme-delogis woocommerce-no-js hfeed custom-cursor woocommerce-active elementor-default elementor-kit-6">
	            <div class="custom-cursor__cursor"></div>
            <div class="custom-cursor__cursor-two"></div>

				<!-- Preloader -->
		<div class="preloader">
			<div class="preloader__image"></div>
		</div>
		<!-- /.preloader -->

	<div id="page" class="site page-wrapper">
		<a class="skip-link screen-reader-text" href="#primary">Skip to content</a>

		
	
                    <!-- the loop -->
                            		<div data-elementor-type="wp-post" data-elementor-id="666" class="elementor elementor-666">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-e5f3292 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="e5f3292" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1225d66" data-id="1225d66" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-21b96e6 elementor-widget elementor-widget-delogis-header" data-id="21b96e6" data-element_type="widget" data-widget_type="delogis-header.default">
				<div class="elementor-widget-container">
				<header class="main-header">
		<nav class="main-menu">
			<div class="main-menu__wrapper">
				<div class="main-menu__wrapper-inner">
					<div class="main-menu__logo logo-retina">
						<a href="https://delogiswp.pixydrops.com/">
							<img decoding="async" width="181" height="54" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/dark-logo.png" alt="Delogis">
						</a>
					</div>
											<div class="main-menu__btn-box ">
							<a class="" href="https://delogiswp.pixydrops.com/make-appointment/"  >Make an Appointment</a>						</div>
										<div class="main-menu__wrapper-inner-content">
						<div class="main-menu__top">
							<div class="main-menu__top-inner">
								<div class="main-menu__top-left">
									<ul class="list-unstyled main-menu__contact-list ml-0">
																					<li>
												<div class="icon">
													<i aria-hidden="true" class="  fas fa-clock"></i>												</div>
												<div class="text">
													<p>Mon to Fri: 9:00am to 6:00pm</p>
												</div>
											</li>
																					<li>
												<div class="icon">
													<i aria-hidden="true" class="  fas fa-envelope"></i>												</div>
												<div class="text">
													<p><a href="mailto:help@company.com">help@company.com</a></p>
												</div>
											</li>
																					<li>
												<div class="icon">
													<i aria-hidden="true" class="  fas fa-map-marker"></i>												</div>
												<div class="text">
													<p>88 Broklyn Golden Street. New Yor</p>
												</div>
											</li>
																			</ul>
									<ul class="list-unstyled main-menu__top-menu ml-0">
																					<li>
												<a class="" href="https://delogiswp.pixydrops.com/about/"  >About</a>											</li>
																					<li>
												<a class=" " href="https://delogiswp.pixydrops.com/our-faqs/"  >Faqs</a>											</li>
																					<li>
												<a class="  " href="https://delogiswp.pixydrops.com/contact/"  >Contact</a>											</li>
																			</ul>
								</div>
																	<div class="main-menu__top-right">
										<div class="main-menu__social">
																							<a   href="https://www.twitter.com/">
													<i aria-hidden="true" class="  fab fa-twitter"></i>												</a>
																							<a   href="https://www.facebook.com/">
													<i aria-hidden="true" class="  fab fa-facebook"></i>												</a>
																							<a   href="https://www.pinterest.com/">
													<i aria-hidden="true" class="  fab fa-pinterest-p"></i>												</a>
																							<a   href="https://www.instagram.com/">
													<i aria-hidden="true" class="  fab fa-instagram"></i>												</a>
																					</div>
									</div>
															</div>
						</div>
						<div class="main-menu__bottom">
							<div class="main-menu__bottom-inner">
								<div class="main-menu__main-menu-box">
									<a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
									<div class="menu-menu-1-container"><ul id="menu-menu-1" class="main-menu__list"><li id="menu-item-671" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home megamenu megamenu-style-alt menu-item-has-children menu-item-671"><a href="https://delogiswp.pixydrops.com/">Home</a><ul class="sub-menu"><li>		<div data-elementor-type="wp-post" data-elementor-id="596" class="elementor elementor-596">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-61ca422 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="61ca422" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ac362bd" data-id="ac362bd" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b11faf4 elementor-widget elementor-widget-delogis-home-showcase-box" data-id="b11faf4" data-element_type="widget" data-widget_type="delogis-home-showcase-box.default">
				<div class="elementor-widget-container">
			    <section class="home-showcase">
        <div class="container">
            <div class="home-showcase__inner">
                <div class="row">
                                            <div class="col-lg-3">
                            <div class="home-showcase__item">
                                <div class="home-showcase__image">
                                    <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/home-showcase-1-1.jpg" alt="alt" title="home-showcase-1-1" >                                    <div class="home-showcase__buttons">
                                                                                    <a href="https://delogiswp.pixydrops.com/" class="thm-btn home-showcase__buttons__item">Multi Page</a>
                                                                                                                            <a href="https://delogiswp.pixydrops.com/one-page-home-one/" class="thm-btn home-showcase__buttons__item">One Page</a>
                                                                            </div>
                                    <!-- /.home-showcase__buttons -->
                                </div><!-- /.home-showcase__image -->
                                <h3 class="home-showcase__title">Home Page 01</h3>                                <!-- /.home-showcase__title -->
                            </div><!-- /.home-showcase__item -->
                        </div><!-- /.col-lg-3 -->
                                            <div class="col-lg-3">
                            <div class="home-showcase__item">
                                <div class="home-showcase__image">
                                    <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/home-showcase-1-2.jpg" alt="alt" title="home-showcase-1-2" >                                    <div class="home-showcase__buttons">
                                                                                    <a href="https://delogiswp.pixydrops.com/home-two/" class="thm-btn home-showcase__buttons__item">Multi Page</a>
                                                                                                                            <a href="https://delogiswp.pixydrops.com/one-page-home-two/" class="thm-btn home-showcase__buttons__item">One Page</a>
                                                                            </div>
                                    <!-- /.home-showcase__buttons -->
                                </div><!-- /.home-showcase__image -->
                                <h3 class="home-showcase__title home-showcase__title">Home Page 02</h3>                                <!-- /.home-showcase__title -->
                            </div><!-- /.home-showcase__item -->
                        </div><!-- /.col-lg-3 -->
                                            <div class="col-lg-3">
                            <div class="home-showcase__item">
                                <div class="home-showcase__image">
                                    <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/home-showcase-1-3.jpg" alt="alt" title="home-showcase-1-3" >                                    <div class="home-showcase__buttons">
                                                                                    <a href="https://delogiswp.pixydrops.com/home-three/" class="thm-btn home-showcase__buttons__item">Multi Page</a>
                                                                                                                            <a href="https://delogiswp.pixydrops.com/one-page-home-three/" class="thm-btn home-showcase__buttons__item">One Page</a>
                                                                            </div>
                                    <!-- /.home-showcase__buttons -->
                                </div><!-- /.home-showcase__image -->
                                <h3 class="home-showcase__title home-showcase__title home-showcase__title">Home Page 03</h3>                                <!-- /.home-showcase__title -->
                            </div><!-- /.home-showcase__item -->
                        </div><!-- /.col-lg-3 -->
                                            <div class="col-lg-3">
                            <div class="home-showcase__item">
                                <div class="home-showcase__image">
                                    <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/home-showcase-1-4.jpg" alt="alt" title="home-showcase-1-4" >                                    <div class="home-showcase__buttons">
                                                                                    <a href="https://delogiswp.pixydrops.com/home-four/" class="thm-btn home-showcase__buttons__item">View  Page</a>
                                                                                                                    </div>
                                    <!-- /.home-showcase__buttons -->
                                </div><!-- /.home-showcase__image -->
                                <h3 class="home-showcase__title home-showcase__title home-showcase__title home-showcase__title">Home Page 04</h3>                                <!-- /.home-showcase__title -->
                            </div><!-- /.home-showcase__item -->
                        </div><!-- /.col-lg-3 -->
                                    </div><!-- /.row -->
            </div><!-- /.home-showcase__inner -->

        </div><!-- /.container -->
    </section>
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		</li></ul></li>
<li id="menu-item-696" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-696"><a href="#">Pages</a>
<ul class="sub-menu">
	<li id="menu-item-672" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-672"><a href="https://delogiswp.pixydrops.com/about/">About</a></li>
	<li id="menu-item-689" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-689"><a href="https://delogiswp.pixydrops.com/our-team/">Our Team</a></li>
	<li id="menu-item-694" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-694"><a href="https://delogiswp.pixydrops.com/team-details/">Team Details</a></li>
	<li id="menu-item-686" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-686"><a href="https://delogiswp.pixydrops.com/make-appointment/">Make Appointment</a></li>
	<li id="menu-item-682" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-682"><a href="https://delogiswp.pixydrops.com/gallery/">Gallery</a></li>
	<li id="menu-item-690" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-690"><a href="https://delogiswp.pixydrops.com/pricing/">Pricing</a></li>
	<li id="menu-item-688" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-688"><a href="https://delogiswp.pixydrops.com/our-faqs/">Our Faqs</a></li>
	<li id="menu-item-795" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-795"><a href="https://delogiswp.pixydrops.com/login/">Login</a></li>
	<li id="menu-item-794" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-794"><a href="https://delogiswp.pixydrops.com/error-page/">404 Error</a></li>
</ul>
</li>
<li id="menu-item-692" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-692"><a href="https://delogiswp.pixydrops.com/services/">Services</a>
<ul class="sub-menu">
	<li id="menu-item-860" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-860"><a href="https://delogiswp.pixydrops.com/services/">Services</a></li>
	<li id="menu-item-681" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-681"><a href="https://delogiswp.pixydrops.com/dating-relationship/">Dating &amp; Relationship</a></li>
	<li id="menu-item-907" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-907"><a href="https://delogiswp.pixydrops.com/self-esteem-issues/">Self Esteem Issues</a></li>
	<li id="menu-item-906" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-906"><a href="https://delogiswp.pixydrops.com/family-psycology/">Family Psycology</a></li>
	<li id="menu-item-905" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-905"><a href="https://delogiswp.pixydrops.com/career-counseling/">Career Counseling</a></li>
	<li id="menu-item-904" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-904"><a href="https://delogiswp.pixydrops.com/anxiety-grief/">Anxiety &#038; Grief</a></li>
	<li id="menu-item-903" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-903"><a href="https://delogiswp.pixydrops.com/young-adult-intensive/">Young &#038; Adult Intensive</a></li>
</ul>
</li>
<li id="menu-item-676" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-676"><a href="https://delogiswp.pixydrops.com/case-one/">Cases</a>
<ul class="sub-menu">
	<li id="menu-item-1148" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1148"><a href="https://delogiswp.pixydrops.com/case-one/">Case One</a></li>
	<li id="menu-item-678" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-678"><a href="https://delogiswp.pixydrops.com/case-two/">Case Two</a></li>
	<li id="menu-item-675" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-675"><a href="https://delogiswp.pixydrops.com/case-details/">Case Details</a></li>
</ul>
</li>
<li id="menu-item-693" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-693"><a href="https://delogiswp.pixydrops.com/delogis-shop/">Shop</a>
<ul class="sub-menu">
	<li id="menu-item-862" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-862"><a href="https://delogiswp.pixydrops.com/delogis-shop/">Products</a></li>
	<li id="menu-item-1119" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1119"><a href="https://delogiswp.pixydrops.com/product/boss-sofa/">Products Details</a></li>
	<li id="menu-item-1123" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1123"><a href="https://delogiswp.pixydrops.com/delogis-cart/?auto_cart=Boss%20Sofa">Cart</a></li>
	<li id="menu-item-1124" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1124"><a href="https://delogiswp.pixydrops.com/delogis-cart/?auto_cart=Boss%20Sofa">Checkout</a></li>
</ul>
</li>
<li id="menu-item-1182" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1182"><a href="https://delogiswp.pixydrops.com/blog/">Blog</a>
<ul class="sub-menu">
	<li id="menu-item-793" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-793"><a href="https://delogiswp.pixydrops.com/blog/">Blog</a></li>
	<li id="menu-item-673" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-673"><a href="https://delogiswp.pixydrops.com/blog-sidebar/">Blog Right Sidebar</a></li>
	<li id="menu-item-1239" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1239"><a href="https://delogiswp.pixydrops.com/blog-sidebar/?sidebar=left-align">Blog Left Sidebar</a></li>
	<li id="menu-item-930" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-930"><a href="https://delogiswp.pixydrops.com/patient-led-advocacy-group-shares-patient-perspective/">Blog Details</a></li>
</ul>
</li>
<li id="menu-item-680" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-680"><a href="https://delogiswp.pixydrops.com/contact/">Contact</a></li>
</ul></div>								</div>
								<div class="main-menu__right">
																			<div class="main-menu__call">
											<div class="main-menu__call-icon">
												<span aria-hidden="true" class="  icon-phone-call"></span>											</div>
											<div class="main-menu__call-content">
												<p class="main-menu__call-sub-title">Have Question?</p>												<h5 class="main-menu__call-number">
													<a href="tel:9288009850">+92 (8800) -9850</a>												</h5>

											</div>
										</div>
																		<div class="main-menu__search-cart-box">
																					<div class="main-menu__search-box">
												<a href="#" class="main-menu__search search-toggler icon-magnifying-glass"></a>
											</div>
																															<div class="main-menu__cart-box">
												<a href="https://delogiswp.pixydrops.com/delogis-cart/" class="main-menu__cart icon-shopping-cart"></a>
											</div>
																			</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</nav>
	</header>

			<div class="stricky-header stricked-menu main-menu">
			<div class="sticky-header__content"></div><!-- /.sticky-header__content -->
		</div><!-- /.stricky-header -->
	



<div class="mobile-nav__wrapper">
	<div class="mobile-nav__overlay mobile-nav__toggler"></div>
	<!-- /.mobile-nav__overlay -->
	<div class="mobile-nav__content">
		<span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

		<div class="logo-box">
			<a href="https://delogiswp.pixydrops.com/" aria-label="logo image">
				<img decoding="async" width="181" height="54" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/light-logo.png" alt="Delogis" />
			</a>
		</div>
		<!-- /.logo-box -->
		<div class="mobile-nav__container"></div>
		<!-- /.mobile-nav__container -->
		<ul class="mobile-nav__contact list-unstyled ml-0">
							<li>
					<i class="fa fa-envelope"></i>
					<a href="mailto:needhelp@delogis.com">needhelp@delogis.com</a>
				</li>
										<li>
					<i class="fa fa-phone-alt"></i>
					<a href="tel:http://666-888-0000">
						666 888 0000					</a>
				</li>
					</ul><!-- /.mobile-nav__contact -->
		<div class="mobile-nav__top">
			<div class="mobile-nav__social">
									<a href="https://www.twiiter.com/" class="fab fa-twitter"></a>
									<a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
									<a href="https://www.pinterest.com/" class="fab fa-pinterest"></a>
									<a href="https://www.instagram.com/" class="fab fa-instagram"></a>
							</div><!-- /.mobile-nav__social -->
		</div><!-- /.mobile-nav__top -->

	</div>
	<!-- /.mobile-nav__content -->
</div>


<div class="search-popup">
	<div class="search-popup__overlay search-toggler"></div>
	<!-- /.search-popup__overlay -->
	<div class="search-popup__content">
		<form role="search" method="get" action="https://delogiswp.pixydrops.com/">
			<label for="search" class="sr-only">search here</label><!-- /.sr-only -->
			<input type="search" name="s" id="search" value="" placeholder="Search Here..." />
			<button type="submit" aria-label="search submit" class="thm-btn">
				<i class="icon-magnifying-glass"></i>
			</button>
		</form>
	</div>
	<!-- /.search-popup__content -->
</div>


	<span data-target="html" class="scroll-to-target scroll-to-top"><i class="fa icon-up-arrow"></i></span>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		                        <!-- end of the loop -->

            
        
		
					<!--Page Header Start-->
<section class="page-header">
	<div class="page-header-bg"></div>

	<div class="container">
		<div class="page-header__inner">
						<h2>
									Page not found							</h2>

										<ul class="thm-breadcrumb list-unstyled ml-0">
					<!-- Breadcrumb NavXT 7.2.0 -->
<li class="home"><span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" title="Go to Delogis." href="https://delogiswp.pixydrops.com" class="home" ><span property="name">Delogis</span></a><meta property="position" content="1"></span></li>
<li class="404 current-item"><span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" title="Go to 404." href="" class="404 current-item" aria-current="page"><span property="name">404</span></a><meta property="position" content="2"></span></li>
				</ul>
					</div>
	</div>
</section>
<!--Page Header End-->		
    		<div data-elementor-type="wp-page" data-elementor-id="762" class="elementor elementor-762">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-9a13889 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="9a13889" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-18389ed" data-id="18389ed" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9d03994 elementor-widget elementor-widget-delogis-error-page" data-id="9d03994" data-element_type="widget" data-widget_type="delogis-error-page.default">
				<div class="elementor-widget-container">
			
    <!--Error Page Start-->
    <section class="error-page">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="error-page__left">
                        <h2 class="error-page__title">404</h2>
                        <h3 class="error-page__tagline">Oops! Page Not Found</h3>                        <p class="error-page__text">The page you are looking for is not exist.</p>
                        <form class="error-page__form">
                            <div class="error-page__form-input">
                                <input type="search" placeholder="Search Here">
                                <button type="submit"><i class="icon-magnifying-glass"></i></button>
                            </div>
                        </form>
                        <div class="error-page__btn-box">
                            <a class="thm-btn error-page__btn" href="http://delogiswp.pixydrops.com/home-one/"  >Back to Home</a>                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="error-page__right">
                        <div class="error-page__img img-bounce">
                            <img src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/error-page-img-1.png" alt="alt" title="error-page-img-1" >                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Error Page End-->
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		



</div><!-- #page -->

<div class="footer-wrapper">
	



    
                    <!-- the loop -->
                            		<div data-elementor-type="wp-post" data-elementor-id="956" class="elementor elementor-956">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-24a6125 elementor-section-full_width site-footer elementor-section-height-default elementor-section-height-default" data-id="24a6125" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c5be98c" data-id="c5be98c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ea0d6e7 elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-delogis-shape" data-id="ea0d6e7" data-element_type="widget" data-widget_type="delogis-shape.default">
				<div class="elementor-widget-container">
			    <div class="site-footer__shape-1 float-bob-y">
        <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/site-footer-shape-1-1.png" alt="alt" title="site-footer-shape-1" >    </div>
		</div>
				</div>
				<div class="elementor-element elementor-element-a8b2c51 elementor-widget elementor-widget-footer-top" data-id="a8b2c51" data-element_type="widget" data-widget_type="footer-top.default">
				<div class="elementor-widget-container">
			    <div class="site-footer__top">
        <div class="container">
            <div class="site-footer__top-inner">
                <div class="site-footer__top-left">
                    <div class="site-footer__top-icon icon-svg-large">
                        <span aria-hidden="true" class="  icon-business-people"></span>                    </div>
                    <div class="site-footer__top-content">
                        <h3>
                            Psychology Timing <span>Monday to Friday 8:00am - 6:00pm</span>
                        </h3>
                    </div>
                </div>
                <div class="site-footer__top-right">
                    <div class="site-footer__social-shape-1 float-bob-y">
                        <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/site-footer-social-shape.png" alt="alt" title="site-footer-social-shape" class="zoom-fade" >                    </div>
                    <div class="site-footer__social-title">
                        <p>Follow on:</p>
                    </div>
                    <div class="site-footer__social">
                                                    <a   href="https://www.facebook.com/">
                                <i aria-hidden="true" class="  fab fa-facebook-f"></i>                            </a>
                                                    <a   href="https://www.twitter.com/">
                                <i aria-hidden="true" class="  fab fa-twitter"></i>                            </a>
                                                    <a   href="https://www.pinterest.com/">
                                <i aria-hidden="true" class="  fab fa-pinterest-p"></i>                            </a>
                                                    <a   href="https://www.pinterest.com/">
                                <i aria-hidden="true" class="  fab fa-instagram"></i>                            </a>
                                            </div>
                </div>
            </div>
        </div>
    </div>
		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d8c1d76 site-footer__middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d8c1d76" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-8e09596" data-id="8e09596" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-99518f4 elementor-widget elementor-widget-footer-about" data-id="99518f4" data-element_type="widget" data-widget_type="footer-about.default">
				<div class="elementor-widget-container">
			    <div class="footer-widget__column footer-widget__about">
        <div class="footer-widget__logo retina-logo">
            <a href="https://delogiswp.pixydrops.com/">
                <img decoding="async" src="https://delogiswp.pixydrops.com/wp-content/uploads/2023/05/light-logo.png" width="182" height="54" alt="Delogis">
            </a>
        </div>
        <p class="footer-widget__about-text">Best psychology &amp; counseling to help you understand   the problems.</p>    </div>
		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6e2de43" data-id="6e2de43" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-958c3b6 elementor-widget elementor-widget-footer-nav-menu" data-id="958c3b6" data-element_type="widget" data-widget_type="footer-nav-menu.default">
				<div class="elementor-widget-container">
			    <div class="footer-widget__column footer-widget__link">
        <div class="footer-widget__title-box">
            <h3 class="footer-widget__title">Explore</h3>        </div>
                    <div class="menu-explore-container"><ul id="menu-explore" class="footer-widget__link-list list-unstyled ml-0"><li id="menu-item-967" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-967"><a href="https://delogiswp.pixydrops.com/about/">About</a></li>
<li id="menu-item-968" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-968"><a href="https://delogiswp.pixydrops.com/make-appointment/">Make Appointment</a></li>
<li id="menu-item-969" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-969"><a href="https://delogiswp.pixydrops.com/blog-sidebar/">Latest Post</a></li>
<li id="menu-item-970" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-970"><a href="https://delogiswp.pixydrops.com/our-team/">Our Team</a></li>
<li id="menu-item-971" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-971"><a href="https://delogiswp.pixydrops.com/our-faqs/">Faqs</a></li>
<li id="menu-item-972" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-972"><a href="https://delogiswp.pixydrops.com/contact/">Contact</a></li>
</ul></div>            </div>
		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d243ac8" data-id="d243ac8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-bd410bd elementor-widget elementor-widget-footer-contact" data-id="bd410bd" data-element_type="widget" data-widget_type="footer-contact.default">
				<div class="elementor-widget-container">
			    <div class="footer-widget__column footer-widget__Contact">
        <div class="footer-widget__title-box">
            <h3 class="footer-widget__title">Contact</h3>        </div>
        <ul class="footer-widget__Contact-list list-unstyled ml-0">
                            <li>
                    <div class="icon">
                        <span aria-hidden="true" class="fas fa-map-marker"></span>                    </div>
                    <div class="text">
                        <span>Visit Office</span>
                        <p class="">66 Broklyn Gold Street. USA</p>                    </div>
                </li>
                            <li>
                    <div class="icon">
                        <span aria-hidden="true" class="fas fa-envelope"></span>                    </div>
                    <div class="text">
                        <span>Send Email</span>
                        <p class=" "><a href="mailto:needhelp@company.com">needhelp@company.com</a></p>                    </div>
                </li>
                            <li>
                    <div class="icon">
                        <span aria-hidden="true" class="fas fa-phone-square"></span>                    </div>
                    <div class="text">
                        <span>Call Anytime</span>
                        <p class="  "><a href="tel:+926668880000">+92 (666) 888 0000</a></p>                    </div>
                </li>
                    </ul>
    </div>
		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c7be9b8" data-id="c7be9b8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9cfac1f elementor-widget elementor-widget-footer-subscribe" data-id="9cfac1f" data-element_type="widget" data-widget_type="footer-subscribe.default">
				<div class="elementor-widget-container">
			
  <div class="footer-widget__column footer-widget__newsletter">
    <div class="footer-widget__title-box">
      <h3 class="footer-widget__title">Newsletter</h3>    </div>
    <p class="footer-widget__newsletter-text">Subscribe our newsletter to get latest updates</p>    <form class="footer-widget__email-box mc-form" data-url="https://xyz.us18.list-manage.com/subscribe/post?u=20e91746ef818cd941998c598&amp;id=cc0ee8140e">
      <div class="footer-widget__email-input-box">
        <input type="email" placeholder="Email address" name="email">
      </div>
      <button type="submit" class="footer-widget__subscribe-btn thm-btn">Register    Yourself</button>
    </form>
    <div class="mc-form__response"></div>
  </div>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-89ec02c elementor-widget elementor-widget-footer-copyright" data-id="89ec02c" data-element_type="widget" data-widget_type="footer-copyright.default">
				<div class="elementor-widget-container">
			    <div class="site-footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="site-footer__bottom-inner">
                        <p class="site-footer__bottom-text">© All Copyright 2023 by <a href="#">Delogis WordPress</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		                        <!-- end of the loop -->

            
        </div><!-- /.footer-wrapper -->

<div id="woosw_wishlist" class="woosw-popup woosw-popup-center"></div>	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='elementor-frontend-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.18.1' media='all' />
<link rel='stylesheet' id='elementor-post-956-css' href='https://delogiswp.pixydrops.com/wp-content/uploads/elementor/css/post-956.css?ver=1702023503' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.25.0' media='all' />
<link rel='stylesheet' id='elementor-post-6-css' href='https://delogiswp.pixydrops.com/wp-content/uploads/elementor/css/post-6.css?ver=1702023503' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://delogiswp.pixydrops.com/wp-content/uploads/elementor/css/global.css?ver=1702023503' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CCastoro%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CLexend%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.4.2' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' media='all' />
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8.4" id="swv-js"></script>
<script id="contact-form-7-js-extra">
var wpcf7 = {"api":{"root":"https:\/\/delogiswp.pixydrops.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8.4" id="contact-form-7-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/layerdrops-toolbar/assets/js/jQuery.style.switcher.min.js?ver=1704183160" id="jquery-style-switcher-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/layerdrops-toolbar/assets/js/color-switcher.js?ver=1704183160" id="layerdrops-toolbar-color-switcher-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.2" id="jquery-ui-datepicker-js"></script>
<script id="jquery-ui-datepicker-js-after">
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/bootstrap/js/bootstrap.min.js?ver=5.0.0" id="bootstrap-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/bootstrap-select/js/bootstrap-select.min.js?ver=1682955174" id="bootstrap-select-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/bxslider/jquery.bxslider.min.js?ver=1682955174" id="jquery-bxslider-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/countdown/countdown.min.js?ver=1682955174" id="countdown-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jarallax/jarallax.min.js?ver=1682955174" id="jarallax-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js?ver=1682955174" id="jquery-ajaxchimp-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-appear/jquery.appear.min.js?ver=1682955174" id="jquery-appear-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js?ver=1682955174" id="jquery-magnific-popup-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/odometer/odometer.min.js?ver=1682955174" id="odometer-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/owl-carousel/owl.carousel.min.js?ver=1682955174" id="owl-carousel-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js?ver=1682955174" id="jquery-circle-progress-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/swiper/swiper.min.js?ver=1682955174" id="swiper-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/wow/wow.js?ver=1682955174" id="wow-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/sharer/sharer.min.js?ver=1682955174" id="sharer-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/timepicker/timePicker.js?ver=1687509198" id="timepicker-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/circleType/jquery.circleType.js?ver=1687509198" id="circletype-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/vendors/circleType/jquery.lettering.min.js?ver=1687509198" id="circleletter-js"></script>
<script id="delogis-addon-script-js-extra">
var delogis_login_object = {"ajaxurl":"https:\/\/delogiswp.pixydrops.com\/wp-admin\/admin-ajax.php","login_redirect_url":"https:\/\/delogiswp.pixydrops.com\/delogis-my-account\/","registration_redirect_url":"https:\/\/delogiswp.pixydrops.com\/delogis-my-account\/","message":"<strong>Error:<\/strong>Please use valid userName or password","check_login":"no","str_login":"Please login to add favorite!"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/delogis-addon/assets/js/delogis-addon.js?ver=1687509198" id="delogis-addon-script-js"></script>
<script id="wc-add-to-cart-variation-js-extra">
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=8.3.1" id="wc-add-to-cart-variation-js" data-wp-strategy="defer"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/slick/slick.min.js?ver=3.5.4" id="slick-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js?ver=3.5.4" id="perfect-scrollbar-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/libs/magnific-popup/jquery.magnific-popup.min.js?ver=3.5.4" id="magnific-popup-js"></script>
<script id="woosq-frontend-js-extra">
var woosq_vars = {"ajax_url":"https:\/\/delogiswp.pixydrops.com\/wp-admin\/admin-ajax.php","nonce":"d9a152a52a","view":"popup","effect":"mfp-3d-unfold","scrollbar":"yes","auto_close":"yes","hashchange":"no","cart_redirect":"no","cart_url":"https:\/\/delogiswp.pixydrops.com\/delogis-cart\/","close":"Close (Esc)","next_prev":"yes","next":"Next (Right arrow key)","prev":"Previous (Left arrow key)","thumbnails_effect":"no","related_slick_params":"{\"slidesToShow\":2,\"slidesToScroll\":2,\"dots\":true,\"arrows\":false,\"adaptiveHeight\":true,\"rtl\":false}","thumbnails_slick_params":"{\"slidesToShow\":1,\"slidesToScroll\":1,\"dots\":true,\"arrows\":true,\"adaptiveHeight\":false,\"rtl\":false}","thumbnails_zoom_params":"{\"duration\":120,\"magnify\":1}","quick_view":"0"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-quick-view/assets/js/frontend.js?ver=3.5.4" id="woosq-frontend-js"></script>
<script id="woosw-frontend-js-extra">
var woosw_vars = {"ajax_url":"https:\/\/delogiswp.pixydrops.com\/wp-admin\/admin-ajax.php","nonce":"15026e5f2b","menu_action":"open_page","perfect_scrollbar":"yes","wishlist_url":"https:\/\/delogiswp.pixydrops.com\/wishlist\/","button_action":"list","message_position":"right-top","button_action_added":"popup","empty_confirm":"This action cannot be undone. Are you sure?","delete_confirm":"This action cannot be undone. Are you sure?","copied_text":"Copied the wishlist link:","menu_text":"Wishlist","button_text":"Add to wishlist","button_text_added":"Browse wishlist","button_normal_icon":"woosw-icon-5","button_added_icon":"woosw-icon-8","button_loading_icon":"woosw-icon-4"};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/woo-smart-wishlist/assets/js/frontend.js?ver=4.7.9" id="woosw-frontend-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/vendors/isotope/isotope.js?ver=2.1.1" id="isotope-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/themes/delogis/assets/js/delogis-theme.js?ver=1704183160" id="delogis-theme-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.18.1" id="elementor-webpack-runtime-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.18.1" id="elementor-frontend-modules-js"></script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.18.1","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"e_swiper_latest":true,"block_editor_assets_optimize":true,"landing-pages":true,"e_image_loading_optimization":true,"e_global_styleguide":true},"urls":{"assets":"https:\/\/delogiswp.pixydrops.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; Delogis","excerpt":""}};
</script>
<script src="https://delogiswp.pixydrops.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.18.1" id="elementor-frontend-js"></script>

</body>

</html>

<!-- Page uncached by LiteSpeed Cache 5.7.0.1 on 2024-01-02 08:12:40 -->